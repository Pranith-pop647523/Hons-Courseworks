# Pranith Praveen s2097010
import socket
import math
import time
import sys


IP = sys.argv[1]
PORT = int(sys.argv[2])
destination = (IP, PORT)
file = sys.argv[3]
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

with open(file, "rb") as f:
    fRead = f.read()
    img = bytearray(fRead)

sleeptime = 0.1

# finding no of packets
imglen = len(img)
fullPackets = math.floor(imglen / 1024)
finalPacket = imglen % 1024
byteEnding = 1024
byteBegin = 0
seqNo = 0
EOF = 0


def sendHelper(packet):
    sock.sendto(packet, destination)


for i in range(fullPackets):
    # when last packet is full
    if i == fullPackets - 1 and finalPacket == 0:
        EOF = 1

    packet = bytearray(seqNo.to_bytes(2, byteorder="big"))
    seqNo += 1
    # add header
    packet.append(EOF)
    # add payload
    data_seg = img[byteBegin:byteEnding]
    for i in data_seg:
        packet.append(i)
    
    sendHelper(packet)
    time.sleep(sleeptime)  # sleep to allow packets to send properly
    byteBegin += 1024
    byteEnding += 1024
# case for when it is final packet
if finalPacket > 0:
    seqNo += 1
    packet = bytearray(seqNo.to_bytes(2, byteorder="big"))
    EOF = 1
    packet.append(EOF)
    data_seg = img[byteBegin:byteEnding]
    for i in data_seg:
        packet.append(i)
    
    sendHelper(packet)

sock.close()
