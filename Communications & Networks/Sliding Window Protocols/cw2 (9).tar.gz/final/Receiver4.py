# Pranith Praveen s2097010
import sys
import time
import socket
import struct


PORT = int(sys.argv[1])
file = sys.argv[2]
window = int(sys.argv[3])
IP = "127.0.0.1"
destination = (IP, PORT)
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # bind socket to given port
sock.bind(destination)
buffsize = 1027  # 1027 as we need header+payload
sleeptime = 60 // 1000


def getSeqNo(data):  # extract seq no froom packet
    return int.from_bytes(data[:2], "big")


# helper fns to make it easier to use struct pack and unpack


def PackHelper(type, data):
    return struct.pack(type, data)


def UnpackHelper(type, data):
    return struct.unpack(type, data[0:2])[0]


# helper fns to send and receive packets


def sendHelper(packet):
    sock.sendto(packet, sendAddress)


def recvHelper(size):
    return sock.recvfrom(size)


img = bytearray()
seqToPacket = {}  # {seqNo:data of packet}
finalSqNo = 2**16
baseReceiver = 1
packets = PackHelper("H", 0)
lastReceived = False
checkIfLast = False
sendAddress = None
while True:
    if baseReceiver > finalSqNo:
        break

    #checking if any data is being sent from sender
    data, clientAddr = recvHelper(buffsize)

    # eof reached
    if data[2] != 0:
        checkIfLast = True
    # change send address when needed
    if not sendAddress:
        sendAddress = clientAddr

    seqNo = UnpackHelper("H", data)
    if checkIfLast == True:
        lastReceived = True
        finalSqNo = seqNo

    # when seqNo is in previous base - window an ACK is sent
    if seqNo in range(baseReceiver - window, baseReceiver):
        packets = PackHelper("H", seqNo)
        # print('error here maybe ?')
        sendHelper(packets)
    # add to dictionary and send ACK
    if seqNo < baseReceiver + window and seqNo >= baseReceiver:
        packetData = data[3:]
        packets = PackHelper("H", seqNo)

        sendHelper(packets)
        seqToPacket[seqNo] = packetData

        # checking if all of packets within window are acked
        if seqNo == baseReceiver:
            allAcked = True
            for windowPacket in range(baseReceiver, baseReceiver + window):
                if not windowPacket in seqToPacket:
                    # implies that it is not a complete window ,so assign base as this number and break
                    baseReceiver = windowPacket
                    allAcked = False
                    break
                else:
                    # add to img file if it is a compelete window
                    img += seqToPacket[windowPacket]
            if allAcked:
                # shift the window and add to the base
                baseReceiver += window

# ACKWindow holds tuples of seqno and packet of seqno for last window
ACKWindow = list()
for sqn in range(0, window):
    # if not in last seqNo append the tuples to the ACKWindow
    if finalSqNo - sqn >= 1:
        ACKWindow.append((finalSqNo - sqn, PackHelper("H", finalSqNo - sqn)))
# send acks mutiple times to ensure sender gets them
for _ in range(5):
    time.sleep(sleeptime)

    for (seqNo, packet) in sorted(ACKWindow):
        sendHelper(packet)


with open(file, "wb") as f:
    f.write(img)

sock.close()
