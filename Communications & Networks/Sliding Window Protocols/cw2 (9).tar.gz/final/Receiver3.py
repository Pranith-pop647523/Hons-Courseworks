# Pranith Praveen s2097010
import socket
import sys


IP = "127.0.0.1"
PORT = int(sys.argv[1])
file = sys.argv[2]
destination = (IP, PORT)
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(destination)  # bind socket to given port
img = bytearray()
buffsize = 1027  # 1027 as we need header+payload
seqNo = 0
nextSeqNo = 0


def getSeqNo(data):  # extract seq no froom packet
    return int.from_bytes(data[:2], "big")


# packet sending and receiving helper fns
def sendHelper(packet):
    sock.sendto(packet, clientAddr)


def recvHelper(size):
    return sock.recvfrom(size)


while True:

    data, clientAddr = recvHelper(buffsize)
    seqNo = getSeqNo(data)
    # seqNo == nextSeqNo implies we received the next packet in order
    if seqNo == nextSeqNo:
        data_seg = data[3:]
        for i in data_seg:
            img.append(i)

        nextSeqNo += 1
    if nextSeqNo == 0:
        validNo = 0
    else:
        validNo = nextSeqNo - 1
    packet = bytearray(validNo.to_bytes(2, byteorder="big"))
    # send ack
    sendHelper(packet)
    # repeat until correct packet is received in order
    while nextSeqNo != seqNo + 1:
        data, clientAddr = recvHelper(buffsize)
        seqNo = getSeqNo(data)
        # print('check here')
        if seqNo == nextSeqNo:
            data_seg = data[3:]
            for i in data_seg:
                img.append(i)

            nextSeqNo += 1
        # sending ack to the sender for received packet
        if nextSeqNo == 0:
            validNo = 0
        else:
            validNo = nextSeqNo - 1
        packet = bytearray(validNo.to_bytes(2, byteorder="big"))
        # send ack
        sendHelper(packet)
    # eof reached
    if data[2] != 0:
        packet = bytearray(seqNo.to_bytes(2, byteorder="big"))
        sendHelper(packet)
        break

with open(file, "wb") as f:
    f.write(img)

sock.close()
