# Pranith Praveen s2097010
import socket
import sys

IP = "127.0.0.1"
PORT = int(sys.argv[1])
destination = (IP, PORT)
file = sys.argv[2]
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(destination)  # bind socket to given port
buffsize = 1027  # 1027 as we need header+payload


img = bytearray()


while True:

    data, clientAddr = sock.recvfrom(buffsize)
    # print('check here')

    data_seg = data[3:]
    for i in data_seg:
        img.append(i)

    # stop if eof is reached
    if data[2] != 0:
        break

with open(file, "wb") as f:
    f.write(img)


sock.close()
