# Pranith Praveen s2097010
import socket
import sys

IP = "127.0.0.1"
PORT = int(sys.argv[1])
file = sys.argv[2]
img = bytearray()
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
destination = (IP, PORT)

sock.bind(destination)  # bind socket to given port
currentSqNo = 0
prevSqNo = 0
buffsize = 1027  # 1027 as we need header+payload


def getSeqNo(data):  # extract seq no froom packet
    return int.from_bytes(data[:2], "big")

#packet sending and receiving helper fns
def sendHelper(packet):
    sock.sendto(packet, clientAddr)

def recvHelper(size):
    return sock.recvfrom(size)

while True:

    data, clientAddr = recvHelper(buffsize)
    if data is None:
        continue
    # extract sequence no
    currentSqNo = getSeqNo(data)
    # checking if duplicate
    if currentSqNo == (prevSqNo + 1):
        prevSqNo = currentSqNo
        data_seg = data[3:]
        for i in data_seg:
            img.append(i)
        
        packet = bytearray(prevSqNo.to_bytes(2, byteorder="big"))
        # sending ack
        sendHelper(packet)
        
    else:
        # send ack if duplicate
        packet = bytearray(prevSqNo.to_bytes(2, byteorder="big"))
        sendHelper(packet)
    # eof reached
    if data[2] != 0:
        end = 0
        packet = bytearray(end.to_bytes(2, byteorder="big"))
        sendHelper(packet)
        break


with open(file, "wb") as f:
    f.write(img)


sock.close()
