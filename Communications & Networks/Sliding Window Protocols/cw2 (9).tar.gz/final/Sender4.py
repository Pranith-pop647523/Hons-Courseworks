# Pranith Praveen s2097010

import socket
import sys
import os
import struct
import time
from threading import Thread, Lock


IP = sys.argv[1]
PORT = int(sys.argv[2])
file = sys.argv[3]
destination = (IP, PORT)
retryTimeout = float(int(sys.argv[4]) / 1000.0)
windowSize = int(sys.argv[5])
WindowRetries = 10
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

packets = list()
# read all packets and append to list
with open(file, "rb") as f:
    packet = f.read(1024)
    while packet:
        packets.append(packet)
        packet = f.read(1024)
    f.close()

nextSeqNo = 1
base = 1
timerOn = True
lastWindowAck = False
isNotQueued = 0
acked = set()
lastWindowCount = 0
lock = Lock()
packlen = len(packets)
fullPackets = [None] * (packlen + 1)
transmissionFinished = False
timeoutClock = None


def getSeqNo(data):  # extract seq no froom packet
    return int.from_bytes(data[:2], "big")


# helper fns to make it easier to use byte fns and send and receive packets


def PackHelper(type, data):
    return struct.pack(type, data)


def UnpackHelper(type, data):
    return struct.unpack(type, data[0:2])[0]


def sendHelper(packet):
    sock.sendto(packet, destination)


def recvHelper(size):
    return sock.recvfrom(size)


# used to send a packet only if it is within the given window
def sendPacket(payload, checkIfLast):

    global timeoutClock
    global timerOn
    global lock
    global base
    global nextSeqNo

    with lock:
        # if next packet is in window
        if nextSeqNo < base + windowSize:
            seqNo = PackHelper("H", nextSeqNo)
            if checkIfLast:
                EOF = PackHelper("B", 1)
            else:
                EOF = PackHelper("B", 0)
            fullPackets[nextSeqNo] = seqNo + EOF + payload
            # print(fullPackets)
            sendHelper(fullPackets[nextSeqNo])
            if base == nextSeqNo:
                timerOn = True
                timeoutClock = (
                    time.perf_counter()
                )  # using perf_counter as we need time during sleep
            nextSeqNo += 1
            return True
        else:
            return False


# thread used to take care of acknowlegments
def receiveAck():

    global base
    global acked
    global timeoutClock
    global tranmissionFinished
    global timeOutThread
    global timerOn
    global lock
    global lastWindowAck

    transmissionFinished = False

    while transmissionFinished == False:

        if transmissionFinished == True:
            break

        data, serverAddr = recvHelper(2)

        ackNum = UnpackHelper("H", data)

        with lock:
            acked.add(ackNum)
            # check if in last window
            if ackNum in range(packlen - windowSize, packlen + 1):
                lastWindowAck = True

            if ackNum == base:
                allAcked = True
                # changing base if every packet is acked
                for pkt in range(base, nextSeqNo):
                    if pkt not in acked:
                        base = pkt
                        allAcked = False
                        break

                if allAcked:
                    base = nextSeqNo
                    timerOn = False
                # starting timer if all not Acked
                else:
                    timerOn = True
                    timeoutClock = time.perf_counter()


# thread to manage timeouts
def timeoutThread():

    global base
    global nextSeqNo
    global lastWindowAck
    global lastWindowCount
    global tranmissionFinished
    global WindowRetries
    global retryTimeout
    global timerOn
    global lock
    global acked
    global timeoutClock

    transmissionFinished = False

    while transmissionFinished == False:

        currentTime = time.perf_counter()
        with lock:

            if transmissionFinished:
                break
            # turn timer on
            if not timerOn or currentTime - timeoutClock < retryTimeout:
                continue

            else:

                timeoutClock = time.perf_counter()
            # if all packets have been acknowledged
            if packlen == len(acked) or lastWindowCount == WindowRetries:
                transmissionFinished = True
                break

            # If in last window
            if lastWindowAck:
                lastWindowCount += 1

            offset = 0
            # send packets till nextSeqNo
            while base + offset < nextSeqNo:
                if base + offset >= len(fullPackets):
                    break
                # resending if not acked list
                if (base + offset) not in acked:
                    sendHelper(fullPackets[base + offset])

                offset += 1


transmissionFinished = False

timeoutClock = time.perf_counter()

timeOutThread = Thread(target=timeoutThread)
ACKThread = Thread(target=receiveAck)

timeStart = time.perf_counter()

ACKThread.start()
timeOutThread.start()

while transmissionFinished == False:

    if packlen == len(acked):
        with lock:
            transmissionFinished = True
    # if all packets were sent
    if isNotQueued == packlen:
        continue
    # get next packet to be sent
    nextPacket = packets[isNotQueued]
    if sendPacket(nextPacket, isNotQueued == packlen - 1):
        isNotQueued += 1

end = time.perf_counter()
trnsmt = end - timeStart
payloadLens = [len(payload) for payload in packets]
fileLen = float(sum(payloadLens)) / 1024.0
rate = fileLen / trnsmt
print(int(rate))
sock.close()
os._exit(os.EX_OK)
