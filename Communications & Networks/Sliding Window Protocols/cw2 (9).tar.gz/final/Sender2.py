# Pranith Praveen s2097010
import socket
import sys
import math
import time

IP = sys.argv[1]
PORT = int(sys.argv[2])
file = sys.argv[3]
retryTimeout = int(sys.argv[4])
rTimeout = retryTimeout / 1000
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
destination = (IP, PORT)


def getSeqNo(data):  # extract seq no froom packet
    return int.from_bytes(data[:2], "big")

#helper fns to send and receive packets
def sendHelper(packet):
    sock.sendto(packet, destination)


def recvHelper(size):
    return sock.recvfrom(size)


with open(file, "rb") as f:
    fRead = f.read()
    img = bytearray(fRead)

# finding no of packets
imglen = len(img)
fullPackets = math.floor(imglen / 1024)
finalPacket = imglen % 1024


byteEnding = 1024
byteBegin = 0
seqNo = 0
EOF = 0
retransmissions = 0
start = time.perf_counter()  # using perf_counter as we need time during sleep
for i in range(fullPackets):

    # when last packet is full
    if i == fullPackets - 1 and finalPacket == 0:
        EOF = 1
    seqNo += 1
    packet = bytearray(seqNo.to_bytes(2, byteorder="big"))

    # add header
    packet.append(EOF)
    # add payload
    data_seg = img[byteBegin:byteEnding]
    for i in data_seg:
        packet.append(i)
    sendHelper(packet)

    ackCorrect = False
    ackReceived = False
    ackSqNo = 0
    # while packet gets acknowledged
    while ackCorrect != True:
        try:
            sock.settimeout(rTimeout)
            data, serverAddr = recvHelper(2)
            ackSqNo = getSeqNo(data)
            ackReceived = True
        except socket.timeout:
            # set ackReceived to False when timeout occurs
            ackReceived = False
        # validating ack
        if seqNo == ackSqNo and ackReceived == True:
            ackCorrect = True
        # retransmit the packet
        else:
            sendHelper(packet)
            retransmissions += 1

    byteBegin += 1024
    byteEnding += 1024

# EOF reached
if finalPacket != 0:
    seqNo += 1
    packet = bytearray(seqNo.to_bytes(2, byteorder="big"))
    EOF = 1
    # Full header created
    packet.append(EOF)
    # Add payload
    data_seg = img[byteBegin:byteEnding]
    for i in data_seg:
        packet.append(i)
    

    ackCorrect = False
    sendHelper(packet)
    ackReceived = False
    ackSqNo = 0

    while ackCorrect == False:
        try:
            sock.settimeout(rTimeout)
            data, serverAddr = recvHelper(2)
            ackSqNo = getSeqNo(data)
            ackReceived = True
            # checking if last packet is received
            if ackSqNo == 0:
                break
        except socket.timeout:
            ackReceived = False

        # validating receieved ack
        if seqNo == ackSqNo and ackReceived == True:
            ackCorrect = True
        else:
            sendHelper(packet)
            retransmissions += 1


end = time.perf_counter()
imgLen = len(img) // 1024
timeEnd = end - start
rate = imgLen // timeEnd
print(int(retransmissions), int(rate))
sock.close()
