# Pranith Praveen s2097010
import socket
import sys
import math
import time
import select


def getSeqNo(data):  # extract seq no froom packet
    return int.from_bytes(data[:2], "big")
#fn to get acks
def receiveAck(base):
    ackSeqNo = base
    sock.settimeout(retryTimeout / 1000)
    data, serverAddr = sock.recvfrom(2)
    ackSeqNo = getSeqNo(data)

    if base < ackSeqNo:
        return ackSeqNo

    else:
        return receiveAck(base)


def sendPacket(seqNo, finalSeqNo, finalPacketSize):
    if seqNo == finalSeqNo:
        EOF = 1
        size = finalPacketSize
    else:
        EOF = 0
        size = 1024

    packet = bytearray(seqNo.to_bytes(2, byteorder="big"))
    packet.append(EOF)
    start = seqNo * 1024
    end = start + size
    data_seg = img[start:end]
    for i in data_seg:
        packet.append(i)
    
    try:
        sock.sendto(packet, destination)
    except socket.error:
        select.select([], [sock], [])


IP = sys.argv[1]
PORT = int(sys.argv[2])
file = sys.argv[3]
retryTimeout = int(sys.argv[4])
windowSize = int(sys.argv[5])
destination = (IP, PORT)
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# make socket non blocking
sock.setblocking(False)

with open(file, "rb") as f:
    fRead = f.read()
    img = bytearray(fRead)

# finding no of packets
imagelen = len(img)
fullPackets = math.floor(imagelen / 1024)
finalPacket = imagelen % 1024
seqNo = 0
EOF = 0
retransmissions = 0
base = 0

finalSeqNo = math.ceil(float(imagelen) / 1024.0)
finalPacketSize = imagelen - (finalSeqNo * 1024)
start = time.perf_counter()
fileSent = False
base = -1
seqNo = 0


try:

    while fileSent != True:
        # send all packets in window
        while seqNo - base <= windowSize and seqNo <= finalSeqNo:
            sendPacket(seqNo, finalSeqNo, finalPacketSize)
            seqNo += 1
            # try receiving acks and set timeout
        try:
            base = receiveAck(base)
        except socket.error as e:
            seqNo = base + 1
            retransmissions += 1
            # ack for final packet
            if base == finalSeqNo:
                fileSent = True
except socket.error as e:
    print(e)


end = time.perf_counter()
imgLen = imagelen / 1024
timeEnd = end - start
rate = imgLen / timeEnd
print(int(rate))
sock.close()
